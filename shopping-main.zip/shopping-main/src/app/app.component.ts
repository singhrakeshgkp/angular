import { Component } from '@angular/core';
import { ToastService } from './core/toast.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  toasts$: Observable<string[]>;

  constructor(private toast: ToastService) {
    this.toasts$ = this.toast.toasts$;
  }
}