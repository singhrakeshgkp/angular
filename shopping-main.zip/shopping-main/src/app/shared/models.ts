export interface Product {
  id: number;
  name: string;
  brand: string;
  price: number;
  imageUrl: string;
  tags?: string[];
}

export interface CartItem {
  product: Product;
  qty: number;
}