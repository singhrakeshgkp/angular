import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductCardComponent } from './product-card.component';
import { Product } from '../../../shared/models';
import { CartService } from '../../../core/cart.service';
import { ToastService } from '../../../core/toast.service';

class CartStub { add = jasmine.createSpy('add'); }
class ToastStub { show = jasmine.createSpy('show'); }

describe('ProductCardComponent', () => {
  let fixture: ComponentFixture<ProductCardComponent>;
  let comp: ProductCardComponent;
  const product: Product = { id: 1, name: 'Phone', brand: 'HCL', price: 123, imageUrl: '' };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProductCardComponent],
      providers: [
        { provide: CartService, useClass: CartStub },
        { provide: ToastService, useClass: ToastStub },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ProductCardComponent);
    comp = fixture.componentInstance;
    comp.product = product;
    fixture.detectChanges();
  });

  it('should add to cart and show toast on add()', () => {
    const cart = TestBed.inject(CartService) as unknown as CartStub;
    const toast = TestBed.inject(ToastService) as unknown as ToastStub;
    comp.add();
    expect(cart.add).toHaveBeenCalledWith(product, 1);
    expect(toast.show).toHaveBeenCalled();
  });
});
