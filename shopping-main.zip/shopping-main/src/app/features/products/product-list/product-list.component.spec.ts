import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ProductListComponent } from './product-list.component';
import { Observable } from 'rxjs';

describe('ProductListComponent', () => {
  let fixture: ComponentFixture<ProductListComponent>;
  let comp: ProductListComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule],
      declarations: [ProductListComponent],
      schemas: [NO_ERRORS_SCHEMA], // ignore <app-product-card>
    }).compileComponents();

    fixture = TestBed.createComponent(ProductListComponent);
    comp = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should filter by search term', fakeAsync(() => {
    let result: any[] = [];
    const sub: Subscription = comp.products$.subscribe((list: any[]) => result = list);
    comp.search.setValue('phone');
    tick(160); // debounceTime(150)
    expect(result.every(p => (p.name + (p.tags || []).join()).toLowerCase().includes('phone'))).toBeTrue();
    sub.unsubscribe();
  }));

  it('should sort by price ascending', fakeAsync(() => {
    let result: any[] = [];
    const sub: Subscription = comp.products$.subscribe((list: any[]) => result = list);
    comp.sort.setValue('price-asc');
    tick(0);
    expect(result).toEqual([...result].sort((a: { price: number }, b: { price: number }) => a.price - b.price));
    sub.unsubscribe();
  }));
});