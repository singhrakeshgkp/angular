import { Product } from '../../shared/models';

export const PRODUCTS: Product[] = [
  { id: 1, name: 'Phone X', brand: 'HCL', price: 699, imageUrl: 'https://picsum.photos/seed/phone1/600/400', tags: ['phone', 'android'] },
  { id: 2, name: 'Phone Y', brand: 'HCL', price: 799, imageUrl: 'https://picsum.photos/seed/phone2/600/400', tags: ['phone', 'android'] },
  { id: 3, name: 'Laptop Pro', brand: 'HCL', price: 1299, imageUrl: 'https://picsum.photos/seed/laptop1/600/400', tags: ['laptop', 'work'] },
  { id: 4, name: 'Headphones', brand: 'Acme', price: 149, imageUrl: 'https://picsum.photos/seed/headphones/600/400', tags: ['audio'] },
  { id: 5, name: 'Camera Z', brand: 'Photon', price: 999, imageUrl: 'https://picsum.photos/seed/camera/600/400', tags: ['camera'] },
];