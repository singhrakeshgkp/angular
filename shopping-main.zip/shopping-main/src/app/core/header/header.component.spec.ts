import { ComponentFixture, TestBed, fakeAsync, tick, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { HeaderComponent } from './header.component';
import { CartService } from '../../cart.service';
import { CartItem, Product } from '../../shared/models';

// Stub implementing CartService API
class CartStub implements Partial<CartService> {
  private countSubject = new BehaviorSubject<number>(0);
  count$: Observable<number> = this.countSubject.asObservable();

  getAll(): CartItem[] { return []; }
  add(product: Product, qty: number = 1): Observable<void> { return of(undefined); }
  remove(id: number): Observable<void> { return of(undefined); }
  clear(): Observable<void> { return of(undefined); }

  // Helper for test to emit count values
  emitCount(value: number) {
    this.countSubject.next(value);
  }
}

describe('HeaderComponent', () => {
  let fixture: ComponentFixture<HeaderComponent>;
  let cartStub: CartStub;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [HeaderComponent],
      providers: [{ provide: CartService, useClass: CartStub }]
    }).compileComponents();

    // Inject CartService as the stub
    cartStub = TestBed.inject(CartService) as unknown as CartStub;
  }));

  it('should create', () => {
    fixture = TestBed.createComponent(HeaderComponent);
    fixture.detectChanges();
    const component = fixture.componentInstance;
    expect(component).toBeTruthy();
  });

  it('should display cart count from service', fakeAsync(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    fixture.detectChanges();

    const badge: HTMLElement = fixture.nativeElement.querySelector('.badge');
    expect(badge.textContent!.trim()).toBe('0');

    // Emit a new cart count
    cartStub.emitCount(3);
    fixture.detectChanges();
    tick(); // allow async pipe to update
    expect(badge.textContent!.trim()).toBe('3');
  }));
});
