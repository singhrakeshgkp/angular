import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { CartItem, Product } from '../shared/models';

@Injectable({ providedIn: 'root' })
export class CartService {
  private items = new Map<number, CartItem>();
  private countSubject = new BehaviorSubject<number>(0);
  count$: Observable<number> = this.countSubject.asObservable();

  getAll(): CartItem[] {
    return Array.from(this.items.values());
  }

  // Return Observable<void> so components/tests can subscribe
  add(product: Product, qty: number = 1): Observable<void> {
    const existing = this.items.get(product.id);
    if (existing) {
      existing.qty += qty;
    } else {
      this.items.set(product.id, { product, qty });
    }
    this.emitCount();
    return of(undefined);
  }

  remove(productId: number): Observable<void> {
    this.items.delete(productId);
    this.emitCount();
    return of(undefined);
  }

  clear(): Observable<void> {
    this.items.clear();
    this.emitCount();
    return of(undefined);
  }

  private emitCount(): void {
    const total = Array.from(this.items.values()).reduce((sum, item) => sum + item.qty, 0);
    this.countSubject.next(total);
  }
}
