import 'zone.js'; // Already required by Angular
import 'zone.js/testing'; // New import path
import { getTestBed } from '@angular/core/testing';
import {
  TestBedInitOptions,
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting
} from '@angular/platform-browser-dynamic/testing';

// Updated the way of handling dynamic imports
declare const require: {
  context(path: string, deep?: boolean, filter?: RegExp): {
    keys(): string[];
    <T>(id: string): T;
  };
};

// Initialize the Angular testing environment with new TestBedInitOptions
getTestBed().initTestEnvironment(
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting(),
  {
    teardown: { destroyAfterEach: true } // Recommended teardown option in Angular 20
  }
);

// Find all the tests.
const context = require.context('./', true, /\.spec\.ts$/);
// Load the modules.
context.keys().forEach(context);
