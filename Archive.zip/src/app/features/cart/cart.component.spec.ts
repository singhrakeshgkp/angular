import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CartComponent } from './cart.component';
import { CartItem, Product } from '../../shared/models';
import { CartService } from '../../core/cart.service';
import { Observable, of } from 'rxjs';

class CartStub {
  private _items: CartItem[] = [];
  getAll(): Observable<CartItem[]> { return of(this._items); }
  set(items: CartItem[]): void { this._items = items; }
  remove = jasmine.createSpy('remove').and.returnValue(of(true)); // Assuming the remove method returns an Observable
  clear = jasmine.createSpy('clear').and.returnValue(of(true)); // Assuming the clear method returns an Observable
}

describe('CartComponent', () => {
  let fixture: ComponentFixture<CartComponent>;
  let comp: CartComponent;
  let cart: CartStub;

  const p: Product = { id: 1, name: 'Phone', brand: 'HCL', price: 100, imageUrl: '' };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CartComponent],
      providers: [{ provide: CartService, useClass: CartStub }]
    }).compileComponents();

    cart = TestBed.inject(CartService) as unknown as CartStub;
    fixture = TestBed.createComponent(CartComponent);
    comp = fixture.componentInstance;
  });

  it('should compute total from items', () => {
    cart.set([{ product: p, qty: 2 }]);
    comp.items$ = cart.getAll();
    comp.items$.subscribe(items => {
      expect(comp.total(items)).toBe(200);
    });
  });

  it('should call remove and clear on service', () => {
    comp.remove(1);
    expect(cart.remove).toHaveBeenCalledWith(1);
    comp.clear();
    expect(cart.clear).toHaveBeenCalled();
  });
});