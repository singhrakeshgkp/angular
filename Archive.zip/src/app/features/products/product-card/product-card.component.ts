import { Component, Input } from '@angular/core';
import { Product } from '../../../shared/models';
import { CartService } from '../../../core/cart.service';
import { ToastService } from '../../../core/toast.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.scss'],
})
export class ProductCardComponent {
  @Input() product!: Product;
  
  constructor(private cart: CartService, private toast: ToastService) {}

  add(): void {
    this.cart.add(this.product, 1).subscribe({
      next: () => this.toast.show(`Added "${this.product.name}" to cart`),
      error: err => console.error('Error adding to cart', err)
    });
  }
}