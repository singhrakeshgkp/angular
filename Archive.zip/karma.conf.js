module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage'),
      require('@angular-devkit/build-angular/plugins/karma')
    ],
    client: {
      jasmine: {
        random: false  // Ensuring tests are run in a predictable order
      },
      clearContext: false // leave Jasmine Spec Runner output visible in browser
    },
    coverageReporter: {
      dir: require('path').join(__dirname, './coverage/shop'),
      subdir: '.',
      // include all sources not just those with spec files
      includeAllSources: true,
      reporters: [
        { type: 'html' },
        { type: 'text-summary' }
      ],
      check: {
        global: {
          statements: 80, // Example threshold, adjust per project needs
          branches: 80,
          functions: 80,
          lines: 80
        }
      }
    },
    reporters: ['progress', 'kjhtml'],
    port: 9876, // default karma port
    colors: true, // enable colors in the output
    logLevel: config.LOG_INFO, // log level config
    autoWatch: true, // enable / disable watching file and executing tests whenever any file changes
    browsers: ['Chrome'],
    singleRun: false, // if true, Karma captures browsers, runs the tests and exits
    restartOnFileChange: true
  });
};