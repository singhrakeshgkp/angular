/***************************************************************************************************
 * Angular requires Zone.js to patch async APIs.
 */
import 'zone.js';  // Included with Angular CLI.

/***************************************************************************************************
 * If you use i18n ($localize) uncomment the next line:
 */
// import '@angular/localize/init';