import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Product } from '../../../shared/models';
import { CartService } from '../../../core/cart.service';
import { ToastService } from '../../../core/toast.service';

@Component({
  selector: 'app-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.scss'],
  imports: [CommonModule],
  standalone: true
})
export class ProductCardComponent {
  @Input() product!: Product;
  constructor(private cart: CartService, private toast: ToastService) {}

  add() {
    this.cart.add(this.product, 1);
    this.toast.show(`Added "${this.product.name}" to cart`);
  }
}