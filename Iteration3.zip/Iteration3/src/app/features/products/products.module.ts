import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductCardComponent } from './product-card/product-card.component';

const routes: Routes = [{ path: '', component: ProductListComponent }];

ProductListComponent.imports = [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routes)];
ProductListComponent.declarations = [ProductCardComponent];

ProductCardComponent.imports = [CommonModule];