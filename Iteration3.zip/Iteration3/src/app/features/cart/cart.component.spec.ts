import { TestBed } from '@angular/core/testing';
import { CartComponent } from './cart.component';
import { CartItem, Product } from '../../shared/models';
import { CartService } from '../../core/cart.service';
import { inject } from '@angular/core';

class CartStub {
  private _items: CartItem[] = [];
  getAll() { return this._items; }
  set(items: CartItem[]) { this._items = items; }
  remove = jasmine.createSpy('remove');
  clear = jasmine.createSpy('clear');
}

describe('CartComponent', () => {
  let comp: CartComponent;
  let cart: CartStub;

  const p: Product = { id: 1, name: 'Phone', brand: 'HCL', price: 100, imageUrl: '' };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CartComponent],
      providers: [{ provide: CartService, useClass: CartStub }],
    }).compileComponents();

    cart = inject(CartService) as unknown as CartStub;
    comp = TestBed.createComponent(CartComponent).componentInstance;
  });

  it('should compute total from items', () => {
    cart.set([{ product: p, qty: 2 }]);
    expect(comp.total()).toBe(200);
  });

  it('should call remove and clear on service', () => {
    comp.remove(1);
    expect(cart.remove).toHaveBeenCalledWith(1);
    comp.clear();
    expect(cart.clear).toHaveBeenCalled();
  });
});