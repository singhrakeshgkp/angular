import { Component } from '@angular/core';
import { CartService } from '../../core/cart.service';
import { CartItem } from '../../shared/models';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
  imports: [CommonModule],
  standalone: true
})
export class CartComponent {
  get items(): CartItem[] { return this.cart.getAll(); }
  constructor(private cart: CartService) {}
  remove(id: number) { this.cart.remove(id); }
  clear() { this.cart.clear(); }
  total() { return this.items.reduce((s, i) => s + i.product.price * i.qty, 0); }
}