import { ToastService } from './toast.service';
import { fakeAsync, tick } from '@angular/core/testing';

describe('ToastService', () => {
  it('should push and auto-remove messages', fakeAsync(() => {
    const s = new ToastService();
    let history: string[][] = [];
    const sub = s.toasts$.subscribe(list => history.push(list));

    s.show('Hello', 10);
    tick(0);
    expect(history[history.length - 1]).toEqual(['Hello']);

    tick(20); // beyond ttl
    expect(history[history.length - 1]).toEqual([]);

    sub.unsubscribe();
  }));
});