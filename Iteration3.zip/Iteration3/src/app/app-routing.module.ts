import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './features/cart/cart.component';

const routes: Routes = [
  { path: '', redirectTo: 'products', pathMatch: 'full' },
  { path: 'cart', component: CartComponent },
  { path: '**', redirectTo: 'products' },
  {
    path: 'products',
    loadComponent: () =>
      import('./features/products/products.component').then(m => m.ProductsComponent)
  }
];

export const AppRoutingModule = RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' });