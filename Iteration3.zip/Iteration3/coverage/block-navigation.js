import { Component, HostListener } from '@angular/core';

@Component({
  selector: 'app-block-navigation',
  template: `
    <div *ngFor="let element of missingCoverageElements; let i = index" 
         [class.highlighted]="i === currentIndex"
         (click)="makeCurrent(i)">
      {{ element.textContent }}
    </div>
  `,
  styles: [`
    .highlighted {
      background-color: yellow;
    }
  `],
  imports: [CommonModule]
})
export class BlockNavigationComponent {
  private missingCoverageClasses = ['.cbranch-no', '.cstat-no', '.fstat-no'];
  private fileListingElements = ['td.pct.low'];
  private notSelector = ':not(' + this.missingCoverageClasses.join('):not(') + ') > ';
  private selector = this.fileListingElements.join(', ') + ', ' + this.notSelector + this.missingCoverageClasses.join(', ' + this.notSelector);
  private missingCoverageElements: Element[];
  private currentIndex: number;

  constructor() {
    this.missingCoverageElements = Array.from(document.querySelectorAll(this.selector));
  }

  toggleClass(index: number): void {
    this.missingCoverageElements[this.currentIndex].classList.remove('highlighted');
    this.missingCoverageElements[index].classList.add('highlighted');
  }

  makeCurrent(index: number): void {
    this.toggleClass(index);
    this.currentIndex = index;
    this.missingCoverageElements[index].scrollIntoView({
      behavior: 'smooth',
      block: 'center',
      inline: 'center'
    });
  }

  goToPrevious(): void {
    let nextIndex = 0;
    if (typeof this.currentIndex !== 'number' || this.currentIndex === 0) {
      nextIndex = this.missingCoverageElements.length - 1;
    } else if (this.missingCoverageElements.length > 1) {
      nextIndex = this.currentIndex - 1;
    }

    this.makeCurrent(nextIndex);
  }

  goToNext(): void {
    let nextIndex = 0;

    if (typeof this.currentIndex === 'number' && this.currentIndex < this.missingCoverageElements.length - 1) {
      nextIndex = this.currentIndex + 1;
    }

    this.makeCurrent(nextIndex);
  }

  @HostListener('window:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent): void {
    if (document.getElementById('fileSearch') === document.activeElement && document.activeElement != null) {
      return;
    }

    switch (event.key) {
      case 'n':
      case 'j':
        this.goToNext();
        break;
      case 'b':
      case 'k':
      case 'p':
        this.goToPrevious();
        break;
    }
  }
}