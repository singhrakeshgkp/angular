/* eslint-disable */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sorter',
  templateUrl: './sorter.component.html',
  styleUrls: ['./sorter.component.css'],
  standalone: true,
  imports: []
})
export class SorterComponent implements OnInit {
  cols: any[];
  currentSort = {
    index: 0,
    desc: false
  };

  constructor() {}

  ngOnInit(): void {
    window.addEventListener('load', this.addSorting.bind(this));
  }

  getTable() {
    return document.querySelector('.coverage-summary');
  }

  getTableHeader() {
    return this.getTable().querySelector('thead tr');
  }

  getTableBody() {
    return this.getTable().querySelector('tbody');
  }

  getNthColumn(n: number) {
    return this.getTableHeader().querySelectorAll('th')[n];
  }

  onFilterInput() {
    const searchValue = document.getElementById('fileSearch').value;
    const rows = document.getElementsByTagName('tbody')[0].children;
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (row.textContent.toLowerCase().includes(searchValue.toLowerCase())) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    }
  }

  addSearchBox() {
    const template = document.getElementById('filterTemplate');
    const templateClone = template.content.cloneNode(true);
    templateClone.getElementById('fileSearch').oninput = this.onFilterInput.bind(this);
    template.parentElement.appendChild(templateClone);
  }

  loadColumns() {
    const colNodes = this.getTableHeader().querySelectorAll('th');
    const cols = [];
    for (let i = 0; i < colNodes.length; i++) {
      const colNode = colNodes[i];
      const col = {
        key: colNode.getAttribute('data-col'),
        sortable: !colNode.getAttribute('data-nosort'),
        type: colNode.getAttribute('data-type') || 'string'
      };
      cols.push(col);
      if (col.sortable) {
        col.defaultDescSort = col.type === 'number';
        colNode.innerHTML += '<span class="sorter"></span>';
      }
    }
    return cols;
  }

  loadRowData(tableRow: HTMLElement) {
    const tableCols = tableRow.querySelectorAll('td');
    const data = {};
    for (let i = 0; i < tableCols.length; i++) {
      const colNode = tableCols[i];
      const col = this.cols[i];
      let val = colNode.getAttribute('data-value');
      if (col.type === 'number') {
        val = Number(val);
      }
      data[col.key] = val;
    }
    return data;
  }

  loadData() {
    const rows = this.getTableBody().querySelectorAll('tr');
    for (let i = 0; i < rows.length; i++) {
      rows[i].data = this.loadRowData(rows[i]);
    }
  }

  sortByIndex(index: number, desc: boolean) {
    const key = this.cols[index].key;
    const sorter = (a, b) => {
      a = a.data[key];
      b = b.data[key];
      return a < b ? -1 : a > b ? 1 : 0;
    };
    let finalSorter = sorter;
    const tableBody = document.querySelector('.coverage-summary tbody');
    const rowNodes = tableBody.querySelectorAll('tr');
    const rows = [];
    if (desc) {
      finalSorter = (a, b) => -1 * sorter(a, b);
    }
    for (let i = 0; i < rowNodes.length; i++) {
      rows.push(rowNodes[i]);
      tableBody.removeChild(rowNodes[i]);
    }
    rows.sort(finalSorter);
    for (let i = 0; i < rows.length; i++) {
      tableBody.appendChild(rows[i]);
    }
  }

  removeSortIndicators() {
    const col = this.getNthColumn(this.currentSort.index);
    let cls = col.className;
    cls = cls.replace(/ sorted$/, '').replace(/ sorted-desc$/, '');
    col.className = cls;
  }

  addSortIndicators() {
    this.getNthColumn(this.currentSort.index).className += this.currentSort.desc ? ' sorted-desc' : ' sorted';
  }

  enableUI() {
    for (let i = 0; i < this.cols.length; i++) {
      if (this.cols[i].sortable) {
        const el = this.getNthColumn(i).querySelector('.sorter').parentElement;
        const ithSorter = (i) => {
          const col = this.cols[i];
          return () => {
            let desc = col.defaultDescSort;
            if (this.currentSort.index === i) {
              desc = !this.currentSort.desc;
            }
            this.sortByIndex(i, desc);
            this.removeSortIndicators();
            this.currentSort.index = i;
            this.currentSort.desc = desc;
            this.addSortIndicators();
          };
        };
        el.addEventListener('click', ithSorter(i));
      }
    }
  }

  addSorting() {
    if (!this.getTable()) {
      return;
    }
    this.cols = this.loadColumns();
    this.loadData();
    this.addSearchBox();
    this.addSortIndicators();
    this.enableUI();
  }
}