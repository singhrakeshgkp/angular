import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ProductListComponent } from './product-list.component';
import { CommonModule } from '@angular/common';

describe('ProductListComponent', () => {
  let fixture: ComponentFixture<ProductListComponent>;
  let comp: ProductListComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, CommonModule],
      declarations: [ProductListComponent],
      schemas: [], // NO_ERRORS_SCHEMA removed
    }).compileComponents();

    fixture = TestBed.createComponent(ProductListComponent);
    comp = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should filter by search term', fakeAsync(() => {
    let result: any[] = [];
    const sub = comp.products$.subscribe(list => result = list);
    comp.search.setValue('phone');
    tick(160); // debounceTime(150)
    expect(result.every(p => (p.name + (p.tags||[]).join()).toLowerCase().includes('phone'))).toBeTrue();
    sub.unsubscribe();
  }));

  it('should sort by price ascending', fakeAsync(() => {
    let result: any[] = [];
    const sub = comp.products$.subscribe(list => result = list);
    comp.sort.setValue('price-asc');
    tick(0);
    expect(result).toEqual([...result].sort((a,b)=>a.price-b.price));
    sub.unsubscribe();
  }));
});