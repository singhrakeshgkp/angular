import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { debounceTime, map, startWith } from 'rxjs/operators';
import { combineLatest, Observable, of } from 'rxjs';
import { Product } from '../../../shared/models';
import { PRODUCTS } from '../products.data';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss'],
  imports: [CommonModule, ReactiveFormsModule],
  standalone: true
})
export class ProductListComponent implements OnInit {
  search = new FormControl('');
  brand = new FormControl('all');
  sort = new FormControl('relevance');

  products$!: Observable<Product[]>;
  brands = ['all', ...Array.from(new Set(PRODUCTS.map(p => p.brand)))];

  ngOnInit(): void {
    const base$ = of(PRODUCTS);
    const search$ = this.search.valueChanges.pipe(startWith(''), debounceTime(150));
    const brand$  = this.brand.valueChanges.pipe(startWith('all'));
    const sort$   = this.sort.valueChanges.pipe(startWith('relevance'));

    this.products$ = combineLatest([base$, search$, brand$, sort$]).pipe(
      map(([items, s, b, so]) => {
        const term = (s ?? '').toString().toLowerCase().trim();
        let list = items.filter(p =>
          (!term || p.name.toLowerCase().includes(term) || p.tags?.some(t => t.includes(term))) &&
          (b === 'all' || p.brand === b)
        );

        if (so === 'price-asc')  list = [...list].sort((a,b)=>a.price-b.price);
        if (so === 'price-desc') list = [...list].sort((a,b)=>b.price-a.price);

        return list;
      })
    );
  }
}