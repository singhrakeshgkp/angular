import { TestBed } from '@angular/core/testing';
import { ProductCardComponent } from './product-card.component';
import { Product } from '../../../shared/models';
import { CartService } from '../../../core/cart.service';
import { ToastService } from '../../../core/toast.service';
import { Component } from '@angular/core';

class CartStub { add = jasmine.createSpy('add'); }
class ToastStub { show = jasmine.createSpy('show'); }

describe('ProductCardComponent', () => {
  let comp: ProductCardComponent;
  const product: Product = { id: 1, name: 'Phone', brand: 'HCL', price: 123, imageUrl: '' };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        Component({
          selector: 'app-product-card',
          standalone: true,
          imports: [],
          template: `...`,
        })
      ],
      providers: [
        { provide: CartService, useClass: CartStub },
        { provide: ToastService, useClass: ToastStub },
      ],
    }).compileComponents();

    comp = TestBed.createComponent(ProductCardComponent).componentInstance;
    comp.product = product;
  });

  it('should add to cart and show toast on add()', () => {
    const cart = TestBed.inject(CartService) as unknown as CartStub;
    const toast = TestBed.inject(ToastService) as unknown as ToastStub;
    comp.add();
    expect(cart.add).toHaveBeenCalledWith(product, 1);
    expect(toast.show).toHaveBeenCalled();
  });
});