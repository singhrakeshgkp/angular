import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { ToastService } from './core/toast.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  imports: []
})
export class AppComponent {
  toasts$: Observable<string[]>;
  constructor(toast: ToastService) { this.toasts$ = toast.toasts$; }
}