import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BehaviorSubject } from 'rxjs';
import { HeaderComponent } from './header.component';
import { CartService } from '../cart.service';
import { Component } from '@angular/core';

class CartStub {
  count$ = new BehaviorSubject<number>(0);
}

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterTestingModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
class HeaderComponentStandalone extends HeaderComponent {}

describe('HeaderComponent', () => {
  let fixture: ComponentFixture<HeaderComponentStandalone>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HeaderComponentStandalone],
      providers: [{ provide: CartService, useClass: CartStub }]
    }).compileComponents();
  });

  it('should display cart count from service', fakeAsync(() => {
    const cart = TestBed.inject(CartService) as unknown as CartStub;
    fixture = TestBed.createComponent(HeaderComponentStandalone);
    fixture.detectChanges();

    const badge: HTMLElement = fixture.nativeElement.querySelector('.badge');
    expect(badge.textContent!.trim()).toBe('0');

    cart.count$.next(3);
    fixture.detectChanges();
    tick(); // allow async pipe to render
    expect(badge.textContent!.trim()).toBe('3');
  }));
});