import { CartService } from './cart.service';
import { Product } from '../shared/models';
import { describe, it, beforeEach, expect } from '@angular/core/testing';

describe('CartService', () => {
  let service: CartService;
  const phone: Product = { id: 1, name: 'Phone', brand: 'HCL', price: 100, imageUrl: '' };

  beforeEach(() => {
    service = new CartService();
  });

  it('should start with zero count', (done) => {
    service.count$.subscribe(c => { expect(c).toBe(0); done(); });
  });

  it('should add items and update count', (done) => {
    let emissions = 0;
    service.count$.subscribe(c => {
      emissions++;
      if (emissions === 2) { // after add
        expect(c).toBe(1);
        done();
      }
    });
    service.add(phone, 1);
  });

  it('should remove items and clear', () => {
    service.add(phone, 2);
    expect(service.getAll()[0].qty).toBe(2);
    service.remove(phone.id);
    expect(service.getAll().length).toBe(0);
    service.add(phone, 1);
    service.clear();
    expect(service.getAll().length).toBe(0);
  });
});