import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CartItem, Product } from '../shared/models';

@Injectable({ providedIn: 'root' })
export class CartService {
  private items = new Map<number, CartItem>();
  private countSubject = new BehaviorSubject<number>(0);
  count$ = this.countSubject.asObservable();

  getAll(): CartItem[] { return Array.from(this.items.values()); }

  add(product: Product, qty = 1) {
    const existing = this.items.get(product.id);
    if (existing) existing.qty += qty;
    else this.items.set(product.id, { product, qty });
    this.emitCount();
  }

  remove(productId: number) {
    this.items.delete(productId);
    this.emitCount();
  }

  clear() {
    this.items.clear();
    this.emitCount();
  }

  private emitCount() {
    const total = Array.from(this.items.values()).reduce((s, it) => s + it.qty, 0);
    this.countSubject.next(total);
  }
}