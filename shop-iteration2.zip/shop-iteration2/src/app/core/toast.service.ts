import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ToastService {
  private _toasts = new BehaviorSubject<string[]>([]);
  toasts$ = this._toasts.asObservable();

  show(msg: string, ttlMs = 1800) {
    const list = [...this._toasts.value, msg];
    this._toasts.next(list);
    setTimeout(() => {
      const after = this._toasts.value.slice(1);
      this._toasts.next(after);
    }, ttlMs);
  }
}