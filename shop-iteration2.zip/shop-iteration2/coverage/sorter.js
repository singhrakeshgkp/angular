/* eslint-disable */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sorter',
  templateUrl: './sorter.component.html',
  styleUrls: ['./sorter.component.css'],
  imports: []
})
export class SorterComponent implements OnInit {
  cols: any[];
  currentSort = {
    index: 0,
    desc: false
  };

  constructor() {}

  ngOnInit(): void {
    window.addEventListener('load', this.addSorting.bind(this));
  }

  private getTable(): HTMLElement | null {
    return document.querySelector('.coverage-summary');
  }

  private getTableHeader(): HTMLElement | null {
    return this.getTable()?.querySelector('thead tr');
  }

  private getTableBody(): HTMLElement | null {
    return this.getTable()?.querySelector('tbody');
  }

  private getNthColumn(n: number): Element | null {
    return this.getTableHeader()?.querySelectorAll('th')[n];
  }

  private onFilterInput(): void {
    const searchValue = (document.getElementById('fileSearch') as HTMLInputElement).value;
    const rows = document.getElementsByTagName('tbody')[0].children;
    Array.from(rows).forEach(row => {
      if (row.textContent?.toLowerCase().includes(searchValue.toLowerCase())) {
        row.setAttribute('style', 'display: ""');
      } else {
        row.setAttribute('style', 'display: "none"');
      }
    });
  }

  private addSearchBox(): void {
    const template = document.getElementById('filterTemplate') as HTMLTemplateElement;
    const templateClone = template.content.cloneNode(true) as DocumentFragment;
    (templateClone.getElementById('fileSearch') as HTMLInputElement).oninput = this.onFilterInput.bind(this);
    template.parentElement?.appendChild(templateClone);
  }

  private loadColumns(): any[] {
    const colNodes = this.getTableHeader()?.querySelectorAll('th');
    const cols = [];
    colNodes?.forEach((colNode, i) => {
      const col = {
        key: colNode.getAttribute('data-col'),
        sortable: colNode.getAttribute('data-nosort') !== 'true',
        type: colNode.getAttribute('data-type') || 'string'
      };
      cols.push(col);
      if (col.sortable) {
        col.defaultDescSort = col.type === 'number';
        colNode.innerHTML += '<span class="sorter"></span>';
      }
    });
    return cols;
  }

  private loadRowData(tableRow: Element): any {
    const tableCols = tableRow.querySelectorAll('td');
    const data = {};
    tableCols.forEach((colNode, i) => {
      const col = this.cols[i];
      let val = colNode.getAttribute('data-value');
      if (col.type === 'number') {
        val = Number(val);
      }
      data[col.key] = val;
    });
    return data;
  }

  private loadData(): void {
    const rows = this.getTableBody()?.querySelectorAll('tr');
    rows?.forEach(row => {
      row['data'] = this.loadRowData(row);
    });
  }

  private sortByIndex(index: number, desc: boolean): void {
    const key = this.cols[index].key;
    const sorter = (a: any, b: any) => {
      return a.data[key] < b.data[key] ? -1 : a.data[key] > b.data[key] ? 1 : 0;
    };
    let finalSorter = desc ? (a: any, b: any) => -1 * sorter(a, b) : sorter;
    const tableBody = this.getTable()?.querySelector('.coverage-summary tbody');
    const rowNodes = tableBody?.querySelectorAll('tr');
    const rows = Array.from(rowNodes || []);
    rows.sort(finalSorter);
    rows.forEach(row => {
      tableBody?.appendChild(row);
    });
  }

  private removeSortIndicators(): void {
    const col = this.getNthColumn(this.currentSort.index);
    if (col) {
      col.className = col.className.replace(/ sorted$/, '').replace(/ sorted-desc$/, '');
    }
  }

  private addSortIndicators(): void {
    const col = this.getNthColumn(this.currentSort.index);
    if (col) {
      col.className += this.currentSort.desc ? ' sorted-desc' : ' sorted';
    }
  }

  private enableUI(): void {
    this.cols.forEach((col, i) => {
      if (col.sortable) {
        const el = this.getNthColumn(i)?.querySelector('.sorter').parentElement;
        if (el) {
          el.addEventListener('click', () => {
            const desc = col.defaultDescSort;
            if (this.currentSort.index === i) {
              this.currentSort.desc = !this.currentSort.desc;
            } else {
              this.currentSort.index = i;
              this.currentSort.desc = desc;
            }
            this.sortByIndex(i, this.currentSort.desc);
            this.removeSortIndicators();
            this.addSortIndicators();
          });
        }
      }
    });
  }

  private addSorting(): void {
    if (!this.getTable()) {
      return;
    }
    this.cols = this.loadColumns();
    this.loadData();
    this.addSearchBox();
    this.addSortIndicators();
    this.enableUI();
  }
}