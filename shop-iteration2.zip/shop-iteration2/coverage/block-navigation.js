// Importing necessary Angular and browser modules
import { Component, HostListener } from '@angular/core';

@Component({
  selector: 'app-block-navigation',
  template: `
    <!-- Template can be expanded or modified as needed -->
    <div *ngFor="let element of missingCoverageElements; let i = index" 
         [class.highlighted]="i === currentIndex">
      <!-- Content representing each element -->
    </div>
  `,
  imports: [CommonModule]
})
export class BlockNavigationComponent {
  // Classes of code we would like to highlight in the file view
  private missingCoverageClasses = ['.cbranch-no', '.cstat-no', '.fstat-no'];

  // Elements to highlight in the file listing view
  private fileListingElements = ['td.pct.low'];

  // We don't want to select elements that are direct descendants of another match
  private notSelector = ':not(' + this.missingCoverageClasses.join('):not(') + ') > '; // becomes `:not(a):not(b) > `

  // Selector that finds elements on the page to which we can jump
  private selector = this.fileListingElements.join(', ') +
    ', ' + this.notSelector +
    this.missingCoverageClasses.join(', ' + this.notSelector); // becomes `:not(a):not(b) > a, :not(a):not(b) > b`

  // The NodeList of matching elements
  missingCoverageElements: NodeListOf<Element>;
  private currentIndex: number;

  constructor() {
    this.missingCoverageElements = document.querySelectorAll(this.selector);
  }

  private toggleClass(index: number): void {
    this.missingCoverageElements.item(this.currentIndex).classList.remove('highlighted');
    this.missingCoverageElements.item(index).classList.add('highlighted');
  }

  private makeCurrent(index: number): void {
    this.toggleClass(index);
    this.currentIndex = index;
    this.missingCoverageElements.item(index).scrollIntoView({
      behavior: 'smooth',
      block: 'center',
      inline: 'center'
    });
  }

  private goToPrevious(): void {
    let nextIndex = 0;
    if (typeof this.currentIndex !== 'number' || this.currentIndex === 0) {
      nextIndex = this.missingCoverageElements.length - 1;
    } else if (this.missingCoverageElements.length > 1) {
      nextIndex = this.currentIndex - 1;
    }

    this.makeCurrent(nextIndex);
  }

  private goToNext(): void {
    let nextIndex = 0;

    if (
      typeof this.currentIndex === 'number' &&
      this.currentIndex < this.missingCoverageElements.length - 1
    ) {
      nextIndex = this.currentIndex + 1;
    }

    this.makeCurrent(nextIndex);
  }

  @HostListener('window:keydown', ['$event'])
  jump(event: KeyboardEvent): void {
    if (
      document.getElementById('fileSearch') === document.activeElement &&
      document.activeElement != null
    ) {
      // if we're currently focused on the search input, we don't want to navigate
      return;
    }

    switch (event.which) {
      case 78: // n
      case 74: // j
        this.goToNext();
        break;
      case 66: // b
      case 75: // k
      case 80: // p
        this.goToPrevious();
        break;
    }
  }
}