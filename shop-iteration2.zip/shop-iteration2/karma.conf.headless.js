// karma.conf.headless.js (ARM-safe, no HTML reporter)
module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-coverage'),
      require('@angular-devkit/build-angular/plugins/karma'),
    ],
    client: { clearContext: true },            // no debug UI
    reporters: ['progress', 'coverage'],       // ⬅️ drop 'kjhtml'
    coverageReporter: {
      dir: require('path').join(__dirname, './coverage'),
      subdir: '.',
      reporters: [{ type: 'html' }, { type: 'text-summary' }],
    },
    browsers: ['ChromeHeadlessArm'],
    customLaunchers: {
      ChromeHeadlessArm: {
        base: 'ChromeHeadless',
        flags: [
          '--headless=new',
          '--disable-gpu',
          '--disable-dev-shm-usage',
        ],
      },
    },
    singleRun: true,
    restartOnFileChange: false,
  });
};